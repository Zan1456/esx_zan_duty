fx_version "adamant"
game "gta5"

name "esx_zan_duty"
description 'Az esx_duty továbbfejlesztett verziója ami jobban működik, mint az eredeti'
author "Zan#1456"
version '1.2'

server_scripts {
  '@es_extended/locale.lua',
  'locale/*.lua',
  'config.lua',
  'server/main.lua',
  'server/jobgenetor.lua',
}

client_scripts {
  '@es_extended/locale.lua',
  'locale/*.lua',
  'config.lua',
  'client/main.lua',
}

