Locales['hu'] = {
	['busy'] = 'Beléptél a szolgálatba',
	['offbusy'] = 'Kiléptél a szolgálatból',
  	['duty1'] = 'Nyomd meg az ~INPUT_CONTEXT~ gombot, hogy ~r~kilépj~s~ a szolgálatból',
  	['duty2'] = 'Nyomd meg az ~INPUT_CONTEXT~ gombot, hogy ~g~belépj~s~ a szolgálatba',
}
