Locales['en'] = {
	['busy'] = 'You went busy mod.',
	['offbusy'] = 'You went on duty.',
  	['duty1'] = 'Press ~INPUT_CONTEXT~ to ~r~exit~s~ duty',
  	['duty2'] = 'Press ~INPUT_CONTEXT~ to ~g~enter~s~ duty',
}
