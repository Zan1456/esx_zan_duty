# Jellemzők
- Készítsen szolgálaton kívüli munkákat csak egy paranccsal
- Sokkal optimalizálóbb, mint mások, és alacsony a használat (0,1 és 0,20% alapjáraton)
- Sok exportáljon szkriptet, például blokkoljon ügyeletet más szkriptek számára
- Több segítség a konfigurációnál
- Több értesítési lehetőség a konfiguráción
- Több szín az ügyeleten és a szolgálaton kívül
- További helyek hozzáadása
- Több helyen állhat be a konfigurációkhoz tartozó feladatokhoz
- Beléphet bármilyen szolgálaton kívüli munkába (mert valaki nem szereti az olyan munkát, mint az offpolice)
- Hozzáadott egy módszert és konfigurációt, hogy ne ellenőrizze az összes zónát az alacsonyabb felhasználás érdekében
- Tiszta kódolás

# FONTOS

Az ehhez a szkripthez tartozó erőforrások további kóddal rendelkeznek az eredeti kód mellett, hogy a feladat teljes mértékben működőképes legyen a telepítéskor. Ha már rendelkezik ilyen erőforrásokkal, mindenképpen távolítsa el vagy tiltsa le őket az esetleges ütközések elkerülése érdekében.

# Forrás előnézete
[Videó] (https://streamable.com/835f5s)

# Követelmények
- ESX
- MySQL
- Agy

# Letöltés és telepítés

- Letöltés https://github.com/Zan1456/esx_zan_duty/
- Helyezze az `erőforrások` mappába

## Telepítés
- Ezt adja hozzá a `server.cfg fájlba a következő sorrendben:
"bash
start esx_upgraded_duty
"